#ifndef BANKMANAGER_H
#define BANKMANAGER_H

#include <iostream>
#include <fstream>
using namespace std;

class BankManager {
private:
    string username;
    string password;

public:
    BankManager(const string& username, const string& password);
    bool login(const string& usernameInput, const string& passwordInput) const;
    void viewAllUserAccountSummaries();
};

#endif 
