#include <iostream>
#include <fstream>
using namespace std;

class BankManager {
private:
    string username;
    string password;

public:
    BankManager(const string& username, const string& password);
    bool login(const string& usernameInput, const string& passwordInput) const;
    void viewAllUserAccountSummaries();
};

BankManager::BankManager(const string& username, const string& password) : username(username), password(password) {}

bool BankManager::login(const string& usernameInput, const string& passwordInput) const {
    ifstream check("managers.txt");
    if (!check.is_open()) {
        cout << "File not found!\n";
        return false;
    }

    string storedUsername, storedPassword;
    while (check >> storedUsername >> storedPassword) {
        if (storedUsername == usernameInput && storedPassword == passwordInput) {
            check.close();
            return true;
        }
    }
    check.close();
    return false;
}

void BankManager::viewAllUserAccountSummaries() {
    ifstream check("users.txt");
    if (!check.is_open()) {
        cout << "File not found!\n";
        return;
    }

    string username;
    double balance;
    while (check >> username >> balance) {
        cout << "Username: " << username << ", Balance: " << balance << endl;
    }
    check.close();
}

int main() {
    BankManager manager("Bailey", "123");
    if (manager.login("Bailey", "123")) {
        cout << "Manager logged in successfully!\n";
        manager.viewAllUserAccountSummaries();
    }
    else {
        cout << "Invalid manager credentials.\n";
    }

    return 0;
}
